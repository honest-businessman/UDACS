# Changelog

## 1.0.2
### Features
- Added `onFracture` to editor

## 1.0.1
### Features
- Added `onFracture` event to `CallbackOptions`. The collider and game object of the instigating object are passed in addition
- Added `CauseFracture()` method to `Fracture` to allow a fracture to be triggered via code.

## 1.0.0
### Features
- Initial release