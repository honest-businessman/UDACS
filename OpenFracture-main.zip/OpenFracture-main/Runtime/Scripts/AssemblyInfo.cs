using System.Runtime.CompilerServices;

// Exposes internal methods of this assembly to the test assembly
[assembly: InternalsVisibleTo("Tests")]